from tornado import ioloop, web, gen
import os,time


class MainHandler(web.RequestHandler):
    @gen.coroutine
    def get(self):
        self.set_header('Content-Type', 'text/event-stream')
        self.set_header('Cache-Control', 'no-cache')
        self.set_header('Access-Control-Allow-Origin', '*')

        while True:
            r = time.time()
            data = "retry:5000\n"+"data: The time is: {0}\n\n".format(r)+"event: newEvent\n"+"data: new event message\n\n"
            print(data)
            yield gen.sleep(2)
            self.write(data)
            self.flush()

def make_app():
    return web.Application([
        (r"/", MainHandler),
    ])

if __name__ == "__main__":
    app = make_app()
    app.listen(8888)
    ioloop.IOLoop.current().start()