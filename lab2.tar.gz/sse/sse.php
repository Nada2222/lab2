<?php
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: *');


while(1){

	echo "data: message\n\n";
	echo "data: hello\n\n";

	echo "event: newEvent\n";
	echo "data: ahmed\n\n";

	echo "event: google\n";
	echo "data: hi\n\n";
	sleep(4);
//	echo "retry: 3000";
	ob_flush();
	flush();
}
?>
