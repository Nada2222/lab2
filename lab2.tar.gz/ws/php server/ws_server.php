<?php
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

require __DIR__.'/vendor/autoload.php';

class Chat implements MessageComponentInterface{
    private $clients;
    function __construct(){
        $this->clients = new SplObjectStorage();
    }

    function onOpen(ConnectionInterface $conn){
        $this->clients->attach($conn);
        echo "new conn: ".$conn->resourceId."\n";
    }
    function onClose(ConnectionInterface $conn){

    }
    function onMessage(ConnectionInterface $from, $msg){
        $msg = json_decode($msg);
        var_dump($msg);
        // echo $msg['user'].": ".$msg['msg']."\n";
        foreach($this->clients as $c){
            $c->send(json_encode($msg));
        }
    }
    function onError(ConnectionInterface $from, Exception $e){
    }
}

$app = IoServer::factory(new HttpServer(new WsServer(new Chat())),8080);
$app->run();
?>