from tornado import websocket, web, ioloop
import json

class MainHandler(websocket.WebSocketHandler):
    clients = set([])

    def check_origin(self, origin):
        return True

    def open(self):
        MainHandler.clients.add(self)

    def on_close(self):
        MainHandler.clients.remove(self)

    def on_message(self, message):
        # print(json.loads(message))
        for c in MainHandler.clients:
            c.write_message(message)

def make_app():
    return web.Application([
        (r"/", MainHandler),
    ])

if __name__ == "__main__":
    app = make_app()
    app.listen(8888)
    ioloop.IOLoop.current().start()
